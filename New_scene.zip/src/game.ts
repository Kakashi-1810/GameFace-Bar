import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"
import Script2 from "../a72de884-e275-490d-b1bb-7f7eaca4777f/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("models/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform3)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape)
const transform4 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform4)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape)
const transform5 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform5)

const bar = new Entity('bar')
engine.addEntity(bar)
bar.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(16.0096492767334, 0, 15.455979347229004),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5494905710220337, 0.9549484252929688, 0.5293241739273071)
})
bar.addComponentOrReplace(transform6)
const gltfShape2 = new GLTFShape("models/Bar 75.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
bar.addComponentOrReplace(gltfShape2)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(31, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 9.858695030212402, 14.089003562927246)
})
invisibleWall.addComponentOrReplace(transform7)

const invisibleWall2 = new Entity('invisibleWall2')
engine.addEntity(invisibleWall2)
invisibleWall2.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(30, 0, 26.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 9.858695030212402, 7.501448631286621)
})
invisibleWall2.addComponentOrReplace(transform8)

const invisibleWall3 = new Entity('invisibleWall3')
engine.addEntity(invisibleWall3)
invisibleWall3.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(30, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 9.858695030212402, 5.57291841506958)
})
invisibleWall3.addComponentOrReplace(transform9)

const invisibleWall4 = new Entity('invisibleWall4')
engine.addEntity(invisibleWall4)
invisibleWall4.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(27.5, 0, 3.5),
  rotation: new Quaternion(-2.1858534354426843e-15, 0.7004309296607971, -8.349785929340214e-8, 0.7137202024459839),
  scale: new Vector3(0.9999827742576599, 9.858695030212402, 5.301138401031494)
})
invisibleWall4.addComponentOrReplace(transform10)

const invisibleWall5 = new Entity('invisibleWall5')
engine.addEntity(invisibleWall5)
invisibleWall5.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(15.5, 0, 1.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(17.857694625854492, 9.806117057800293, 1.0000020265579224)
})
invisibleWall5.addComponentOrReplace(transform11)

const invisibleWall6 = new Entity('invisibleWall6')
engine.addEntity(invisibleWall6)
invisibleWall6.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(24.52245330810547, 0, 2.1682705879211426),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(-0.38797739148139954, 9.806117057800293, 1.7205501794815063)
})
invisibleWall6.addComponentOrReplace(transform12)

const invisibleWall7 = new Entity('invisibleWall7')
engine.addEntity(invisibleWall7)
invisibleWall7.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(7, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(-0.38797739148139954, 9.806117057800293, 1.7205501794815063)
})
invisibleWall7.addComponentOrReplace(transform13)

const invisibleWall8 = new Entity('invisibleWall8')
engine.addEntity(invisibleWall8)
invisibleWall8.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(6, 0, 3),
  rotation: new Quaternion(6.769058504026821e-16, 0.6986027956008911, -8.327993583634452e-8, 0.7155097126960754),
  scale: new Vector3(-0.38797739148139954, 9.806117057800293, 1.7205508947372437)
})
invisibleWall8.addComponentOrReplace(transform14)

const invisibleWall9 = new Entity('invisibleWall9')
engine.addEntity(invisibleWall9)
invisibleWall9.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(2.5, 0, 3),
  rotation: new Quaternion(6.769058504026821e-16, 0.6986027956008911, -8.327993583634452e-8, 0.7155097126960754),
  scale: new Vector3(-0.38797739148139954, 9.806117057800293, 1.7205512523651123)
})
invisibleWall9.addComponentOrReplace(transform15)

const invisibleWall10 = new Entity('invisibleWall10')
engine.addEntity(invisibleWall10)
invisibleWall10.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(4.5, 0, 3),
  rotation: new Quaternion(6.769058504026821e-16, 0.6986027956008911, -8.327993583634452e-8, 0.7155097126960754),
  scale: new Vector3(-0.38802018761634827, 3.4571516513824463, 2.051081418991089)
})
invisibleWall10.addComponentOrReplace(transform16)

const invisibleWall11 = new Entity('invisibleWall11')
engine.addEntity(invisibleWall11)
invisibleWall11.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(4.5, 8, 2.5),
  rotation: new Quaternion(6.769058504026821e-16, 0.6986027956008911, -8.327993583634452e-8, 0.7155097126960754),
  scale: new Vector3(-0.3880268633365631, 1.460707187652588, 2.108579397201538)
})
invisibleWall11.addComponentOrReplace(transform17)

const invisibleWall12 = new Entity('invisibleWall12')
engine.addEntity(invisibleWall12)
invisibleWall12.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(2, 0, 5.5),
  rotation: new Quaternion(-5.344304998544658e-10, -0.01195499300956726, -4.3275150574118015e-8, 0.9999285936355591),
  scale: new Vector3(-0.3884648382663727, 9.806117057800293, 6.159730434417725)
})
invisibleWall12.addComponentOrReplace(transform18)

const invisibleWall13 = new Entity('invisibleWall13')
engine.addEntity(invisibleWall13)
invisibleWall13.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(1, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 9.80283260345459, 13.713903427124023)
})
invisibleWall13.addComponentOrReplace(transform19)

const invisibleWall14 = new Entity('invisibleWall14')
engine.addEntity(invisibleWall14)
invisibleWall14.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(1.6202983856201172, 0, 6.459198951721191),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 9.80283260345459, 5.368156433105469)
})
invisibleWall14.addComponentOrReplace(transform20)

const invisibleWall15 = new Entity('invisibleWall15')
engine.addEntity(invisibleWall15)
invisibleWall15.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(2, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 9.80283260345459, 7.2147088050842285)
})
invisibleWall15.addComponentOrReplace(transform21)

const invisibleWall16 = new Entity('invisibleWall16')
engine.addEntity(invisibleWall16)
invisibleWall16.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(5.5, 1.7346272329632484e-7, 29.5),
  rotation: new Quaternion(-1.187735644903108e-15, 0.7082335352897644, -8.44279952616489e-8, -0.7059782147407532),
  scale: new Vector3(1.0000014305114746, 9.80283260345459, 8.280303955078125)
})
invisibleWall16.addComponentOrReplace(transform22)

const invisibleWall17 = new Entity('invisibleWall17')
engine.addEntity(invisibleWall17)
invisibleWall17.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(26.5, 1.7346272329632484e-7, 30),
  rotation: new Quaternion(-1.187735644903108e-15, 0.7082335352897644, -8.44279952616489e-8, -0.7059782147407532),
  scale: new Vector3(1.000001311302185, 9.80283260345459, 8.28030014038086)
})
invisibleWall17.addComponentOrReplace(transform23)

const invisibleWall18 = new Entity('invisibleWall18')
engine.addEntity(invisibleWall18)
invisibleWall18.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(21, 1.7346272329632484e-7, 30.5),
  rotation: new Quaternion(-1.187735644903108e-15, 0.7082335352897644, -8.44279952616489e-8, -0.7059782147407532),
  scale: new Vector3(0.999996542930603, 9.80283260345459, 4.421541690826416)
})
invisibleWall18.addComponentOrReplace(transform24)

const invisibleWall19 = new Entity('invisibleWall19')
engine.addEntity(invisibleWall19)
invisibleWall19.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(11.5, 1.7346272329632484e-7, 30.5),
  rotation: new Quaternion(-1.187735644903108e-15, 0.7082335352897644, -8.44279952616489e-8, -0.7059782147407532),
  scale: new Vector3(0.9999975562095642, 9.80283260345459, 4.798437595367432)
})
invisibleWall19.addComponentOrReplace(transform25)

const invisibleWall20 = new Entity('invisibleWall20')
engine.addEntity(invisibleWall20)
invisibleWall20.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(16.5, 3.6392650604248047, 30.675865173339844),
  rotation: new Quaternion(-1.187735644903108e-15, 0.7082335352897644, -8.44279952616489e-8, -0.7059782147407532),
  scale: new Vector3(0.9999979734420776, 6.3393964767456055, 4.798425674438477)
})
invisibleWall20.addComponentOrReplace(transform26)

const invisibleRamp = new Entity('invisibleRamp')
engine.addEntity(invisibleRamp)
invisibleRamp.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(2, 0, 2),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.8624318838119507, 3.4131503105163574, 2.3617491722106934)
})
invisibleRamp.addComponentOrReplace(transform27)

const invisibleWall21 = new Entity('invisibleWall21')
engine.addEntity(invisibleWall21)
invisibleWall21.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(4.339056015014648, 3.237703323364258, 16.63437271118164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.219374656677246, 0.46094298362731934, 28.149478912353516)
})
invisibleWall21.addComponentOrReplace(transform28)

const invisibleWall22 = new Entity('invisibleWall22')
engine.addEntity(invisibleWall22)
invisibleWall22.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(4.240086555480957, 3.6366467475891113, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.9963488578796387, 0.18536686897277832, 2.319880962371826)
})
invisibleWall22.addComponentOrReplace(transform29)

const invisibleWall23 = new Entity('invisibleWall23')
engine.addEntity(invisibleWall23)
invisibleWall23.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(27.699846267700195, 3.237703323364258, 16.355188369750977),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.934494495391846, 0.46094298362731934, 28.149478912353516)
})
invisibleWall23.addComponentOrReplace(transform30)

const invisibleWall24 = new Entity('invisibleWall24')
engine.addEntity(invisibleWall24)
invisibleWall24.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(16, 3.237703323364258, 26.91336441040039),
  rotation: new Quaternion(-3.119916423988963e-16, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(6.296563148498535, 0.46094298362731934, 31.872167587280273)
})
invisibleWall24.addComponentOrReplace(transform31)

const invisibleWall25 = new Entity('invisibleWall25')
engine.addEntity(invisibleWall25)
invisibleWall25.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(12.931448936462402, 0, 23.918880462646484),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall25.addComponentOrReplace(transform32)

const invisibleWall26 = new Entity('invisibleWall26')
engine.addEntity(invisibleWall26)
invisibleWall26.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(18.645050048828125, 0, 23.99164390563965),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall26.addComponentOrReplace(transform33)

const invisibleWall27 = new Entity('invisibleWall27')
engine.addEntity(invisibleWall27)
invisibleWall27.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(24.838600158691406, 0, 23.963788986206055),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall27.addComponentOrReplace(transform34)

const invisibleWall28 = new Entity('invisibleWall28')
engine.addEntity(invisibleWall28)
invisibleWall28.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(24.97837257385254, 0, 18.37201499938965),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall28.addComponentOrReplace(transform35)

const invisibleWall29 = new Entity('invisibleWall29')
engine.addEntity(invisibleWall29)
invisibleWall29.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(6.774657249450684, 0, 24.017210006713867),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall29.addComponentOrReplace(transform36)

const invisibleWall30 = new Entity('invisibleWall30')
engine.addEntity(invisibleWall30)
invisibleWall30.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(6.600116729736328, 0, 18.33519744873047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall30.addComponentOrReplace(transform37)

const invisibleWall31 = new Entity('invisibleWall31')
engine.addEntity(invisibleWall31)
invisibleWall31.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(6.591662406921387, 0, 12.904032707214355),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall31.addComponentOrReplace(transform38)

const invisibleWall32 = new Entity('invisibleWall32')
engine.addEntity(invisibleWall32)
invisibleWall32.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(6.591662406921387, 0, 12.904032707214355),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall32.addComponentOrReplace(transform39)

const invisibleWall33 = new Entity('invisibleWall33')
engine.addEntity(invisibleWall33)
invisibleWall33.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(6.737665176391602, 0, 7.058483123779297),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall33.addComponentOrReplace(transform40)

const invisibleWall34 = new Entity('invisibleWall34')
engine.addEntity(invisibleWall34)
invisibleWall34.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(24.935131072998047, 0, 12.96102523803711),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall34.addComponentOrReplace(transform41)

const invisibleWall35 = new Entity('invisibleWall35')
engine.addEntity(invisibleWall35)
invisibleWall35.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(24.66403579711914, 0, 7.201991081237793),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.48271608352661133, 3.4552688598632812, -0.5692690014839172)
})
invisibleWall35.addComponentOrReplace(transform42)

const invisibleWall36 = new Entity('invisibleWall36')
engine.addEntity(invisibleWall36)
invisibleWall36.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(18, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.8543179035186768)
})
invisibleWall36.addComponentOrReplace(transform43)

const invisibleWall37 = new Entity('invisibleWall37')
engine.addEntity(invisibleWall37)
invisibleWall37.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(17.216266632080078, 0, 9.677276611328125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.3037025928497314)
})
invisibleWall37.addComponentOrReplace(transform44)

const invisibleWall38 = new Entity('invisibleWall38')
engine.addEntity(invisibleWall38)
invisibleWall38.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(27, 0, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 14.902763366699219)
})
invisibleWall38.addComponentOrReplace(transform45)

const invisibleWall39 = new Entity('invisibleWall39')
engine.addEntity(invisibleWall39)
invisibleWall39.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(22.20771598815918, 0, 13.25881576538086),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.3037025928497314)
})
invisibleWall39.addComponentOrReplace(transform46)

const invisibleWall40 = new Entity('invisibleWall40')
engine.addEntity(invisibleWall40)
invisibleWall40.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(22.41788673400879, 0, 19.474735260009766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.3037025928497314)
})
invisibleWall40.addComponentOrReplace(transform47)

const invisibleWall41 = new Entity('invisibleWall41')
engine.addEntity(invisibleWall41)
invisibleWall41.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(17.536468505859375, 0, 22.56591796875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.3037025928497314)
})
invisibleWall41.addComponentOrReplace(transform48)

const invisibleWall42 = new Entity('invisibleWall42')
engine.addEntity(invisibleWall42)
invisibleWall42.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(21.93038558959961, 0, 26.5245361328125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.3037025928497314)
})
invisibleWall42.addComponentOrReplace(transform49)

const invisibleWall43 = new Entity('invisibleWall43')
engine.addEntity(invisibleWall43)
invisibleWall43.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(10.023417472839355, 0, 14.3333740234375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall43.addComponentOrReplace(transform50)

const invisibleWall44 = new Entity('invisibleWall44')
engine.addEntity(invisibleWall44)
invisibleWall44.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(7.87032413482666, 0, 14.3333740234375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall44.addComponentOrReplace(transform51)

const invisibleWall45 = new Entity('invisibleWall45')
engine.addEntity(invisibleWall45)
invisibleWall45.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(7.832383155822754, 0, 16.79320526123047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall45.addComponentOrReplace(transform52)

const invisibleWall46 = new Entity('invisibleWall46')
engine.addEntity(invisibleWall46)
invisibleWall46.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(9.986023902893066, 0, 16.79320526123047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall46.addComponentOrReplace(transform53)

const invisibleWall47 = new Entity('invisibleWall47')
engine.addEntity(invisibleWall47)
invisibleWall47.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(9.986023902893066, 0, 19.370189666748047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall47.addComponentOrReplace(transform54)

const invisibleWall48 = new Entity('invisibleWall48')
engine.addEntity(invisibleWall48)
invisibleWall48.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(9.986023902893066, 0, 21.96709632873535),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall48.addComponentOrReplace(transform55)

const invisibleWall49 = new Entity('invisibleWall49')
engine.addEntity(invisibleWall49)
invisibleWall49.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(9.986023902893066, 0, 24.346303939819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall49.addComponentOrReplace(transform56)

const invisibleWall50 = new Entity('invisibleWall50')
engine.addEntity(invisibleWall50)
invisibleWall50.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(7.960382461547852, 0, 24.346303939819336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall50.addComponentOrReplace(transform57)

const invisibleWall51 = new Entity('invisibleWall51')
engine.addEntity(invisibleWall51)
invisibleWall51.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(7.960382461547852, 0, 21.985383987426758),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall51.addComponentOrReplace(transform58)

const invisibleWall52 = new Entity('invisibleWall52')
engine.addEntity(invisibleWall52)
invisibleWall52.setParent(_scene)
const transform59 = new Transform({
  position: new Vector3(7.960382461547852, 0, 19.387290954589844),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall52.addComponentOrReplace(transform59)

const invisibleWall53 = new Entity('invisibleWall53')
engine.addEntity(invisibleWall53)
invisibleWall53.setParent(_scene)
const transform60 = new Transform({
  position: new Vector3(7.87032413482666, 0, 16.768402099609375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1365735530853271, 1.1274809837341309, 0.17575474083423615)
})
invisibleWall53.addComponentOrReplace(transform60)

const invisibleWall54 = new Entity('invisibleWall54')
engine.addEntity(invisibleWall54)
invisibleWall54.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(10, 0, 14.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.3701514005661011, 0.6921559572219849)
})
invisibleWall54.addComponentOrReplace(transform61)

const invisibleWall55 = new Entity('invisibleWall55')
engine.addEntity(invisibleWall55)
invisibleWall55.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(7.9923095703125, 0, 14.574490547180176),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.3701514005661011, 0.6921559572219849)
})
invisibleWall55.addComponentOrReplace(transform62)

const invisibleWall56 = new Entity('invisibleWall56')
engine.addEntity(invisibleWall56)
invisibleWall56.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(7.9923095703125, 0, 24.18936538696289),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.3701514005661011, 0.6921559572219849)
})
invisibleWall56.addComponentOrReplace(transform63)

const invisibleWall57 = new Entity('invisibleWall57')
engine.addEntity(invisibleWall57)
invisibleWall57.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(10.031234741210938, 0, 24.18936538696289),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.3701514005661011, 0.6921559572219849)
})
invisibleWall57.addComponentOrReplace(transform64)

const invisibleWall58 = new Entity('invisibleWall58')
engine.addEntity(invisibleWall58)
invisibleWall58.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(8.011622428894043, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.3701514005661011, 0.6921559572219849)
})
invisibleWall58.addComponentOrReplace(transform65)

const invisibleWall59 = new Entity('invisibleWall59')
engine.addEntity(invisibleWall59)
invisibleWall59.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(10.123841285705566, 0, 21.712284088134766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.3701514005661011, 0.6921559572219849)
})
invisibleWall59.addComponentOrReplace(transform66)

const invisibleWall60 = new Entity('invisibleWall60')
engine.addEntity(invisibleWall60)
invisibleWall60.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(10, 0, 22),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3114700317382812, 0.3701514005661011, 0.9442700743675232)
})
invisibleWall60.addComponentOrReplace(transform67)

const invisibleWall61 = new Entity('invisibleWall61')
engine.addEntity(invisibleWall61)
invisibleWall61.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(10, 0, 19.349456787109375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3114700317382812, 0.3701514005661011, 0.9442700743675232)
})
invisibleWall61.addComponentOrReplace(transform68)

const invisibleWall62 = new Entity('invisibleWall62')
engine.addEntity(invisibleWall62)
invisibleWall62.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(10, 0.14101529121398926, 16.688692092895508),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3114700317382812, 0.3701514005661011, 0.9442700743675232)
})
invisibleWall62.addComponentOrReplace(transform69)

const invisibleWall63 = new Entity('invisibleWall63')
engine.addEntity(invisibleWall63)
invisibleWall63.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(8.02611255645752, 0.14101529121398926, 16.688692092895508),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3114700317382812, 0.3701514005661011, 0.9442700743675232)
})
invisibleWall63.addComponentOrReplace(transform70)

const invisibleWall64 = new Entity('invisibleWall64')
engine.addEntity(invisibleWall64)
invisibleWall64.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(8.02611255645752, 0.14101529121398926, 19.23987579345703),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3114700317382812, 0.3701514005661011, 0.9442700743675232)
})
invisibleWall64.addComponentOrReplace(transform71)

const invisibleWall65 = new Entity('invisibleWall65')
engine.addEntity(invisibleWall65)
invisibleWall65.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(8.02611255645752, 0.14101529121398926, 21.95127296447754),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3114700317382812, 0.3701514005661011, 0.9442700743675232)
})
invisibleWall65.addComponentOrReplace(transform72)

const invisibleWall66 = new Entity('invisibleWall66')
engine.addEntity(invisibleWall66)
invisibleWall66.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(6.942556381225586, 3.5590310096740723, 13.406105041503906),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.15228891372680664, 0.9436640739440918, 20.718185424804688)
})
invisibleWall66.addComponentOrReplace(transform73)

const invisibleWall67 = new Entity('invisibleWall67')
engine.addEntity(invisibleWall67)
invisibleWall67.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(24.674631118774414, 3.676090717315674, 13.406105041503906),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.15228891372680664, 0.9436640739440918, 20.718185424804688)
})
invisibleWall67.addComponentOrReplace(transform74)

const invisibleWall68 = new Entity('invisibleWall68')
engine.addEntity(invisibleWall68)
invisibleWall68.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(15.959236145019531, 3.68943452835083, 23.56145477294922),
  rotation: new Quaternion(0.010691560804843903, 0.7083547711372375, 0.010294348932802677, 0.7057005167007446),
  scale: new Vector3(0.1522890031337738, 0.9436639547348022, 18.21574592590332)
})
invisibleWall68.addComponentOrReplace(transform75)

const invisibleWall69 = new Entity('invisibleWall69')
engine.addEntity(invisibleWall69)
invisibleWall69.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(28.117267608642578, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.506606101989746, 1, 1.3037025928497314)
})
invisibleWall69.addComponentOrReplace(transform76)

const invisibleWall70 = new Entity('invisibleWall70')
engine.addEntity(invisibleWall70)
invisibleWall70.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(22.19463348388672, 0, 7.173040390014648),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.3918019533157349, 1, 1.3037025928497314)
})
invisibleWall70.addComponentOrReplace(transform77)

const invisibleWall71 = new Entity('invisibleWall71')
engine.addEntity(invisibleWall71)
invisibleWall71.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(4, 3.9895191192626953, 0.7459288835525513),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.7492878437042236, 1.127532720565796, 0.25956976413726807)
})
invisibleWall71.addComponentOrReplace(transform78)

const invisibleWall72 = new Entity('invisibleWall72')
engine.addEntity(invisibleWall72)
invisibleWall72.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(5, 3.989518880844116, 1.502122402191162),
  rotation: new Quaternion(-2.646502496753593e-17, 0.707481861114502, -8.433839582266955e-8, 0.7067315578460693),
  scale: new Vector3(1.749288558959961, 1.127532720565796, 0.2595698833465576)
})
invisibleWall72.addComponentOrReplace(transform79)

const invisibleWall73 = new Entity('invisibleWall73')
engine.addEntity(invisibleWall73)
invisibleWall73.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(9.90113639831543, 0, 15.542235374450684),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall73.addComponentOrReplace(transform80)

const invisibleWall74 = new Entity('invisibleWall74')
engine.addEntity(invisibleWall74)
invisibleWall74.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(7.970958709716797, 0, 15.53571891784668),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall74.addComponentOrReplace(transform81)

const invisibleWall75 = new Entity('invisibleWall75')
engine.addEntity(invisibleWall75)
invisibleWall75.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(7.973187446594238, 0, 18.071414947509766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall75.addComponentOrReplace(transform82)

const invisibleWall76 = new Entity('invisibleWall76')
engine.addEntity(invisibleWall76)
invisibleWall76.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(10.013230323791504, 0, 18.074710845947266),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall76.addComponentOrReplace(transform83)

const invisibleWall77 = new Entity('invisibleWall77')
engine.addEntity(invisibleWall77)
invisibleWall77.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(9.97973346710205, 0, 20.80290985107422),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall77.addComponentOrReplace(transform84)

const invisibleWall78 = new Entity('invisibleWall78')
engine.addEntity(invisibleWall78)
invisibleWall78.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(7.925383567810059, 0, 20.822195053100586),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall78.addComponentOrReplace(transform85)

const invisibleWall79 = new Entity('invisibleWall79')
engine.addEntity(invisibleWall79)
invisibleWall79.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(7.937875747680664, 0, 23.333154678344727),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall79.addComponentOrReplace(transform86)

const invisibleWall80 = new Entity('invisibleWall80')
engine.addEntity(invisibleWall80)
invisibleWall80.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(9.906318664550781, 0, 23.334074020385742),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 0.7993510365486145, 1)
})
invisibleWall80.addComponentOrReplace(transform87)

const invisibleWall81 = new Entity('invisibleWall81')
engine.addEntity(invisibleWall81)
invisibleWall81.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(3.7315196990966797, 4.053986549377441, 15.548042297363281),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.4869439899921417, 0.3318089246749878, 2.498039484024048)
})
invisibleWall81.addComponentOrReplace(transform88)

const invisibleWall82 = new Entity('invisibleWall82')
engine.addEntity(invisibleWall82)
invisibleWall82.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(3.6813652515411377, 4.053986549377441, 11.005002975463867),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.4869439899921417, 0.3318089246749878, 2.498039484024048)
})
invisibleWall82.addComponentOrReplace(transform89)

const invisibleWall83 = new Entity('invisibleWall83')
engine.addEntity(invisibleWall83)
invisibleWall83.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(3.7315196990966797, 4.053986549377441, 19.39029312133789),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.4869439899921417, 0.3318089246749878, 2.498039484024048)
})
invisibleWall83.addComponentOrReplace(transform90)

const invisibleWall84 = new Entity('invisibleWall84')
engine.addEntity(invisibleWall84)
invisibleWall84.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(12.28420639038086, 4.053986549377441, 26.797847747802734),
  rotation: new Quaternion(1.5394203364713045e-15, -0.7071067690849304, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(0.4869439899921417, 0.3318089246749878, 2.498039484024048)
})
invisibleWall84.addComponentOrReplace(transform91)

const invisibleWall85 = new Entity('invisibleWall85')
engine.addEntity(invisibleWall85)
invisibleWall85.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(16.74885368347168, 4.053986549377441, 26.64055633544922),
  rotation: new Quaternion(1.5394203364713045e-15, -0.7071067690849304, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(0.4869439899921417, 0.3318089246749878, 2.498039484024048)
})
invisibleWall85.addComponentOrReplace(transform92)

const invisibleWall86 = new Entity('invisibleWall86')
engine.addEntity(invisibleWall86)
invisibleWall86.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(20.827102661132812, 4.053986549377441, 26.687219619750977),
  rotation: new Quaternion(1.5394203364713045e-15, -0.7071067690849304, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(0.4869439899921417, 0.3318089246749878, 2.498039484024048)
})
invisibleWall86.addComponentOrReplace(transform93)

const invisibleWall87 = new Entity('invisibleWall87')
engine.addEntity(invisibleWall87)
invisibleWall87.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(28.5, 4.053986549377441, 19),
  rotation: new Quaternion(-0.006583991460502148, -0.9998944997787476, -0.000085150204540696, -0.012949824333190918),
  scale: new Vector3(0.48694419860839844, 0.33180874586105347, 2.498041868209839)
})
invisibleWall87.addComponentOrReplace(transform94)

const invisibleWall88 = new Entity('invisibleWall88')
engine.addEntity(invisibleWall88)
invisibleWall88.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(28.528268814086914, 4.053986549377441, 15.164762496948242),
  rotation: new Quaternion(-0.006583991460502148, -0.9998944997787476, -0.000085150204540696, -0.012949824333190918),
  scale: new Vector3(0.48694437742233276, 0.3318086862564087, 2.4980428218841553)
})
invisibleWall88.addComponentOrReplace(transform95)

const invisibleWall89 = new Entity('invisibleWall89')
engine.addEntity(invisibleWall89)
invisibleWall89.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(28.515398025512695, 4.053986549377441, 11.239245414733887),
  rotation: new Quaternion(-0.006583991460502148, -0.9998944997787476, -0.000085150204540696, -0.012949824333190918),
  scale: new Vector3(0.4869444668292999, 0.3318086564540863, 2.4980432987213135)
})
invisibleWall89.addComponentOrReplace(transform96)

const invisibleWall90 = new Entity('invisibleWall90')
engine.addEntity(invisibleWall90)
invisibleWall90.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(5.1631927490234375, 4.005985260009766, 28.778900146484375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 3.040048360824585, 1)
})
invisibleWall90.addComponentOrReplace(transform97)

const invisibleWall91 = new Entity('invisibleWall91')
engine.addEntity(invisibleWall91)
invisibleWall91.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(2.629974365234375, 0, 3.2371225357055664),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 0.7633547782897949)
})
invisibleWall91.addComponentOrReplace(transform98)

const invisibleWall92 = new Entity('invisibleWall92')
engine.addEntity(invisibleWall92)
invisibleWall92.setParent(_scene)
const transform99 = new Transform({
  position: new Vector3(1.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1.034817099571228)
})
invisibleWall92.addComponentOrReplace(transform99)

const invisibleWall93 = new Entity('invisibleWall93')
engine.addEntity(invisibleWall93)
invisibleWall93.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(1.5, 0, 13),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1.034817099571228)
})
invisibleWall93.addComponentOrReplace(transform100)

const invisibleWall94 = new Entity('invisibleWall94')
engine.addEntity(invisibleWall94)
invisibleWall94.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(1.4115371704101562, 0, 17.960012435913086),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1.034817099571228)
})
invisibleWall94.addComponentOrReplace(transform101)

const invisibleWall95 = new Entity('invisibleWall95')
engine.addEntity(invisibleWall95)
invisibleWall95.setParent(_scene)
const transform102 = new Transform({
  position: new Vector3(1.4115371704101562, 0, 17.960012435913086),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.5, 1.034817099571228)
})
invisibleWall95.addComponentOrReplace(transform102)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
script1.init(options)
script2.init(options)
script1.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script1.spawn(invisibleWall2, {"enabled":true}, createChannel(channelId, invisibleWall2, channelBus))
script1.spawn(invisibleWall3, {"enabled":true}, createChannel(channelId, invisibleWall3, channelBus))
script1.spawn(invisibleWall4, {"enabled":true}, createChannel(channelId, invisibleWall4, channelBus))
script1.spawn(invisibleWall5, {"enabled":true}, createChannel(channelId, invisibleWall5, channelBus))
script1.spawn(invisibleWall6, {"enabled":true}, createChannel(channelId, invisibleWall6, channelBus))
script1.spawn(invisibleWall7, {"enabled":true}, createChannel(channelId, invisibleWall7, channelBus))
script1.spawn(invisibleWall8, {"enabled":true}, createChannel(channelId, invisibleWall8, channelBus))
script1.spawn(invisibleWall9, {"enabled":true}, createChannel(channelId, invisibleWall9, channelBus))
script1.spawn(invisibleWall10, {"enabled":true}, createChannel(channelId, invisibleWall10, channelBus))
script1.spawn(invisibleWall11, {"enabled":true}, createChannel(channelId, invisibleWall11, channelBus))
script1.spawn(invisibleWall12, {"enabled":true}, createChannel(channelId, invisibleWall12, channelBus))
script1.spawn(invisibleWall13, {"enabled":true}, createChannel(channelId, invisibleWall13, channelBus))
script1.spawn(invisibleWall14, {"enabled":true}, createChannel(channelId, invisibleWall14, channelBus))
script1.spawn(invisibleWall15, {"enabled":true}, createChannel(channelId, invisibleWall15, channelBus))
script1.spawn(invisibleWall16, {"enabled":true}, createChannel(channelId, invisibleWall16, channelBus))
script1.spawn(invisibleWall17, {"enabled":true}, createChannel(channelId, invisibleWall17, channelBus))
script1.spawn(invisibleWall18, {"enabled":true}, createChannel(channelId, invisibleWall18, channelBus))
script1.spawn(invisibleWall19, {"enabled":true}, createChannel(channelId, invisibleWall19, channelBus))
script1.spawn(invisibleWall20, {"enabled":true}, createChannel(channelId, invisibleWall20, channelBus))
script2.spawn(invisibleRamp, {"enabled":true}, createChannel(channelId, invisibleRamp, channelBus))
script1.spawn(invisibleWall21, {"enabled":true}, createChannel(channelId, invisibleWall21, channelBus))
script1.spawn(invisibleWall22, {"enabled":true}, createChannel(channelId, invisibleWall22, channelBus))
script1.spawn(invisibleWall23, {"enabled":true}, createChannel(channelId, invisibleWall23, channelBus))
script1.spawn(invisibleWall24, {"enabled":true}, createChannel(channelId, invisibleWall24, channelBus))
script1.spawn(invisibleWall25, {"enabled":true}, createChannel(channelId, invisibleWall25, channelBus))
script1.spawn(invisibleWall26, {"enabled":true}, createChannel(channelId, invisibleWall26, channelBus))
script1.spawn(invisibleWall27, {"enabled":true}, createChannel(channelId, invisibleWall27, channelBus))
script1.spawn(invisibleWall28, {"enabled":true}, createChannel(channelId, invisibleWall28, channelBus))
script1.spawn(invisibleWall29, {"enabled":true}, createChannel(channelId, invisibleWall29, channelBus))
script1.spawn(invisibleWall30, {"enabled":true}, createChannel(channelId, invisibleWall30, channelBus))
script1.spawn(invisibleWall31, {"enabled":true}, createChannel(channelId, invisibleWall31, channelBus))
script1.spawn(invisibleWall32, {"enabled":true}, createChannel(channelId, invisibleWall32, channelBus))
script1.spawn(invisibleWall33, {"enabled":true}, createChannel(channelId, invisibleWall33, channelBus))
script1.spawn(invisibleWall34, {"enabled":true}, createChannel(channelId, invisibleWall34, channelBus))
script1.spawn(invisibleWall35, {"enabled":true}, createChannel(channelId, invisibleWall35, channelBus))
script1.spawn(invisibleWall36, {"enabled":true}, createChannel(channelId, invisibleWall36, channelBus))
script1.spawn(invisibleWall37, {"enabled":true}, createChannel(channelId, invisibleWall37, channelBus))
script1.spawn(invisibleWall38, {"enabled":true}, createChannel(channelId, invisibleWall38, channelBus))
script1.spawn(invisibleWall39, {"enabled":true}, createChannel(channelId, invisibleWall39, channelBus))
script1.spawn(invisibleWall40, {"enabled":true}, createChannel(channelId, invisibleWall40, channelBus))
script1.spawn(invisibleWall41, {"enabled":true}, createChannel(channelId, invisibleWall41, channelBus))
script1.spawn(invisibleWall42, {"enabled":true}, createChannel(channelId, invisibleWall42, channelBus))
script1.spawn(invisibleWall43, {"enabled":true}, createChannel(channelId, invisibleWall43, channelBus))
script1.spawn(invisibleWall44, {"enabled":true}, createChannel(channelId, invisibleWall44, channelBus))
script1.spawn(invisibleWall45, {"enabled":true}, createChannel(channelId, invisibleWall45, channelBus))
script1.spawn(invisibleWall46, {"enabled":true}, createChannel(channelId, invisibleWall46, channelBus))
script1.spawn(invisibleWall47, {"enabled":true}, createChannel(channelId, invisibleWall47, channelBus))
script1.spawn(invisibleWall48, {"enabled":true}, createChannel(channelId, invisibleWall48, channelBus))
script1.spawn(invisibleWall49, {"enabled":true}, createChannel(channelId, invisibleWall49, channelBus))
script1.spawn(invisibleWall50, {"enabled":true}, createChannel(channelId, invisibleWall50, channelBus))
script1.spawn(invisibleWall51, {"enabled":true}, createChannel(channelId, invisibleWall51, channelBus))
script1.spawn(invisibleWall52, {"enabled":true}, createChannel(channelId, invisibleWall52, channelBus))
script1.spawn(invisibleWall53, {"enabled":true}, createChannel(channelId, invisibleWall53, channelBus))
script1.spawn(invisibleWall54, {"enabled":true}, createChannel(channelId, invisibleWall54, channelBus))
script1.spawn(invisibleWall55, {"enabled":true}, createChannel(channelId, invisibleWall55, channelBus))
script1.spawn(invisibleWall56, {"enabled":true}, createChannel(channelId, invisibleWall56, channelBus))
script1.spawn(invisibleWall57, {"enabled":true}, createChannel(channelId, invisibleWall57, channelBus))
script1.spawn(invisibleWall58, {"enabled":true}, createChannel(channelId, invisibleWall58, channelBus))
script1.spawn(invisibleWall59, {"enabled":true}, createChannel(channelId, invisibleWall59, channelBus))
script1.spawn(invisibleWall60, {"enabled":true}, createChannel(channelId, invisibleWall60, channelBus))
script1.spawn(invisibleWall61, {"enabled":true}, createChannel(channelId, invisibleWall61, channelBus))
script1.spawn(invisibleWall62, {"enabled":true}, createChannel(channelId, invisibleWall62, channelBus))
script1.spawn(invisibleWall63, {"enabled":true}, createChannel(channelId, invisibleWall63, channelBus))
script1.spawn(invisibleWall64, {"enabled":true}, createChannel(channelId, invisibleWall64, channelBus))
script1.spawn(invisibleWall65, {"enabled":true}, createChannel(channelId, invisibleWall65, channelBus))
script1.spawn(invisibleWall66, {"enabled":true}, createChannel(channelId, invisibleWall66, channelBus))
script1.spawn(invisibleWall67, {"enabled":true}, createChannel(channelId, invisibleWall67, channelBus))
script1.spawn(invisibleWall68, {"enabled":true}, createChannel(channelId, invisibleWall68, channelBus))
script1.spawn(invisibleWall69, {"enabled":true}, createChannel(channelId, invisibleWall69, channelBus))
script1.spawn(invisibleWall70, {"enabled":true}, createChannel(channelId, invisibleWall70, channelBus))
script1.spawn(invisibleWall71, {"enabled":true}, createChannel(channelId, invisibleWall71, channelBus))
script1.spawn(invisibleWall72, {"enabled":true}, createChannel(channelId, invisibleWall72, channelBus))
script1.spawn(invisibleWall73, {"enabled":true}, createChannel(channelId, invisibleWall73, channelBus))
script1.spawn(invisibleWall74, {"enabled":true}, createChannel(channelId, invisibleWall74, channelBus))
script1.spawn(invisibleWall75, {"enabled":true}, createChannel(channelId, invisibleWall75, channelBus))
script1.spawn(invisibleWall76, {"enabled":true}, createChannel(channelId, invisibleWall76, channelBus))
script1.spawn(invisibleWall77, {"enabled":true}, createChannel(channelId, invisibleWall77, channelBus))
script1.spawn(invisibleWall78, {"enabled":true}, createChannel(channelId, invisibleWall78, channelBus))
script1.spawn(invisibleWall79, {"enabled":true}, createChannel(channelId, invisibleWall79, channelBus))
script1.spawn(invisibleWall80, {"enabled":true}, createChannel(channelId, invisibleWall80, channelBus))
script1.spawn(invisibleWall81, {"enabled":true}, createChannel(channelId, invisibleWall81, channelBus))
script1.spawn(invisibleWall82, {"enabled":true}, createChannel(channelId, invisibleWall82, channelBus))
script1.spawn(invisibleWall83, {"enabled":true}, createChannel(channelId, invisibleWall83, channelBus))
script1.spawn(invisibleWall84, {"enabled":true}, createChannel(channelId, invisibleWall84, channelBus))
script1.spawn(invisibleWall85, {"enabled":true}, createChannel(channelId, invisibleWall85, channelBus))
script1.spawn(invisibleWall86, {"enabled":true}, createChannel(channelId, invisibleWall86, channelBus))
script1.spawn(invisibleWall87, {"enabled":true}, createChannel(channelId, invisibleWall87, channelBus))
script1.spawn(invisibleWall88, {"enabled":true}, createChannel(channelId, invisibleWall88, channelBus))
script1.spawn(invisibleWall89, {"enabled":true}, createChannel(channelId, invisibleWall89, channelBus))
script1.spawn(invisibleWall90, {"enabled":true}, createChannel(channelId, invisibleWall90, channelBus))
script1.spawn(invisibleWall91, {"enabled":true}, createChannel(channelId, invisibleWall91, channelBus))
script1.spawn(invisibleWall92, {"enabled":true}, createChannel(channelId, invisibleWall92, channelBus))
script1.spawn(invisibleWall93, {"enabled":true}, createChannel(channelId, invisibleWall93, channelBus))
script1.spawn(invisibleWall94, {"enabled":true}, createChannel(channelId, invisibleWall94, channelBus))
script1.spawn(invisibleWall95, {"enabled":true}, createChannel(channelId, invisibleWall95, channelBus))